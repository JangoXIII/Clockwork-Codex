#!/bin/sh
printf '\033c\033]0;%s\a' Mod Editor
base_path="$(dirname "$(realpath "$0")")"
"$base_path/mod_editor" "$@"
